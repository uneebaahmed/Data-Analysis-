Drop table customer_info_datasource;
-- only info for customers from US 
Create table customer_info_datasource(
Customer varchar(25),
State varchar(100),
Customer_Lifetime_Value	decimal(10,6),
Response varchar(8),
Coverage varchar(8),
Education varchar(40),
Effective_To_Date date,
EmploymentStatus varchar(30),
Gender varchar (1),
Income Number,
Location_Code varchar(25),	
Marital_Status	varchar(10),
Monthly_Premium_Auto Number,	
Months_Since_Last_Claim Number,
Months_Since_Policy_Inception Number,
Open_Complaints Number,
TotalPolicies Number,
Policy_Type	varchar(25),
Policy varchar(25),
Renew_Offer_Type varchar(8),
Sales_Channel	 varchar(25),
Total_Claim_Amount Number(10,6),
Vehicle_Class	varchar(25),
Vehicle_Size varchar(35));



Drop table US_Customers_datasource;
Create table US_Customers_datasource(
row_id number,
order_id varchar(30),
order_date date,
ship_date date,
ship_mode Varchar(30),
customer_id varchar(23),
customer_name varchar(100),
Segment varchar (23),
Country varchar (200),
City varchar (45),
State varchar (40),
postal_code Number,
Region varchar (20),
product_id varchar (30),
Category varchar (30),
sub_category varchar(30),
product_name varchar (200),
Sales Number, 
Quantity Number,
Discount Number, 
Profit Number);


Drop table CA_Customers_datasource;
Create table CA_Customers_datasource(
row_id number,
order_id varchar(30),
order_date date,
ship_date date,
ship_mode Varchar(30),
customer_id varchar(23),
customer_name varchar(100),
Segment varchar (23),
Country varchar (25),
City varchar (45),
State varchar (40),
postal_code Number,
Region varchar (20),
product_id varchar (30),
Category varchar (30),
sub_category varchar(30),
product_name varchar (200),
Sales Number, 
Quantity Number,
Discount Number, 
Profit Number);



--Drop table returns;
drop table returns_datasource;
CREATE TABLE returns_datasource(
Returned varchar(8),
order_id varchar(30));
    
    